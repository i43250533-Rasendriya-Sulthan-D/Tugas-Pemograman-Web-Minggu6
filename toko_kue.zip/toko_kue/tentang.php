<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tentang Kami - Sweet Cake</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Playfair+Display:ital,wght@0,600;1,400&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        :root {
            --primary: #e63946;
            --primary-hover: #c1121f;
            --secondary: #ffb703;
            --accent: #fdf0ed;
            --text-dark: #1d3557;
            --text-muted: #6c757d;
            --bg-light: #fafafa;
            --white: #ffffff;
            --shadow-sm: 0 4px 6px -1px rgba(0, 0, 0, 0.05);
            --shadow-lg: 0 20px 25px -5px rgba(0, 0, 0, 0.08), 0 8px 10px -6px rgba(0, 0, 0, 0.01);
            --radius-md: 16px;
            --radius-lg: 24px;
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: var(--bg-light);
            color: var(--text-dark);
            line-height: 1.6;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 24px;
        }

        .navbar {
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(12px);
            position: sticky;
            top: 0;
            z-index: 1000;
            border-bottom: 1px solid rgba(0, 0, 0, 0.05);
            padding: 16px 0;
        }

        .navbar .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .brand {
            font-family: 'Playfair Display', serif;
            font-size: 1.75rem;
            font-weight: 700;
            color: var(--primary);
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .nav-links {
            display: flex;
            gap: 32px;
            list-style: none;
        }

        .nav-links a {
            text-decoration: none;
            color: var(--text-dark);
            font-weight: 600;
            font-size: 0.95rem;
            transition: var(--transition);
            position: relative;
        }

        .nav-links a:hover,
        .nav-links a.active {
            color: var(--primary);
        }

        .nav-links a::after {
            content: '';
            position: absolute;
            bottom: -6px;
            left: 0;
            width: 0%;
            height: 2px;
            background: var(--primary);
            transition: var(--transition);
            border-radius: 2px;
        }

        .nav-links a:hover::after,
        .nav-links a.active::after {
            width: 100%;
        }

        .page-header {
            background: linear-gradient(135deg, #fff5f5 0%, #fff0f3 100%);
            padding: 60px 0;
            border-radius: 0 0 30px 30px;
            margin-bottom: 48px;
            text-align: center;
        }

        .page-header h1 {
            font-family: 'Playfair Display', serif;
            font-size: 2.75rem;
            color: var(--text-dark);
            margin-bottom: 8px;
        }

        .page-header p {
            color: var(--text-muted);
            font-size: 1.05rem;
        }

        /* Grid Layout Utama */
        .about-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 40px;
            align-items: center;
            margin-bottom: 64px;
        }

        .about-card {
            background: var(--white);
            border-radius: var(--radius-lg);
            padding: 40px;
            box-shadow: var(--shadow-sm);
            border: 1px solid rgba(0, 0, 0, 0.04);
        }

        .about-card h2 {
            font-family: 'Playfair Display', serif;
            font-size: 2rem;
            color: var(--text-dark);
            margin-bottom: 16px;
        }

        .about-card p {
            color: var(--text-muted);
            font-size: 1rem;
            line-height: 1.8;
            margin-bottom: 16px;
        }

        .features-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 24px;
            margin-bottom: 64px;
        }

        .feature-card {
            background: var(--white);
            padding: 32px 24px;
            border-radius: var(--radius-md);
            border: 1px solid rgba(0, 0, 0, 0.04);
            box-shadow: var(--shadow-sm);
            transition: var(--transition);
            text-align: center;
        }

        .feature-card:hover {
            transform: translateY(-6px);
            box-shadow: var(--shadow-lg);
        }

        .feature-icon {
            width: 60px;
            height: 60px;
            background: var(--accent);
            color: var(--primary);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            margin: 0 auto 20px auto;
        }

        .feature-card h3 {
            font-size: 1.15rem;
            font-weight: 700;
            margin-bottom: 8px;
        }

        .feature-card p {
            color: var(--text-muted);
            font-size: 0.9rem;
            line-height: 1.6;
        }

        .contact-section {
            background: var(--white);
            border-radius: var(--radius-lg);
            padding: 48px;
            box-shadow: var(--shadow-sm);
            border: 1px solid rgba(0, 0, 0, 0.04);
            margin-bottom: 80px;
        }

        .contact-header {
            text-align: center;
            margin-bottom: 36px;
        }

        .contact-header h2 {
            font-family: 'Playfair Display', serif;
            font-size: 2rem;
            color: var(--text-dark);
        }

        .contact-header p {
            color: var(--text-muted);
            font-size: 0.95rem;
            margin-top: 4px;
        }

        .contact-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 24px;
        }

        .contact-item {
            display: flex;
            align-items: center;
            gap: 16px;
            padding: 20px;
            background: var(--bg-light);
            border-radius: var(--radius-md);
            text-decoration: none;
            color: var(--text-dark);
            transition: var(--transition);
        }

        .contact-item:hover {
            background: var(--accent);
            transform: translateY(-3px);
        }

        .contact-icon {
            width: 48px;
            height: 48px;
            border-radius: 12px;
            background: var(--white);
            color: var(--primary);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.25rem;
            box-shadow: var(--shadow-sm);
        }

        .contact-info h4 {
            font-size: 0.85rem;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .contact-info p {
            font-size: 1rem;
            font-weight: 700;
            color: var(--text-dark);
        }

        @media (max-width: 768px) {
            .about-grid { grid-template-columns: 1fr; }
            .page-header h1 { font-size: 2rem; }
            .about-card, .contact-section { padding: 24px; }
        }
    </style>
</head>

<body>

    <nav class="navbar">
        <div class="container">
            <a href="index.php" class="brand">
                <i class="fa-solid fa-cake-candles"></i> Sweet Cake
            </a>
            <ul class="nav-links">
                <li><a href="index.php">Beranda</a></li>
                <li><a href="produk.php">Produk</a></li>
                <li><a href="tentang.php" class="active">Tentang Kami</a></li>
            </ul>
        </div>
    </nav>

    <section class="page-header">
        <div class="container">
            <h1>Tentang Sweet Cake</h1>
            <p>Mengenal lebih dekat cerita, nilai, dan dedikasi di balik setiap potong kue kami</p>
        </div>
    </section>

    <main class="container">

        <section class="about-card" style="margin-bottom: 48px;">
            <h2>Cerita Kami</h2>
            <p>
                <strong>Sweet Cake</strong> adalah usaha mikro, kecil, dan menengah (UMKM) yang bergerak dalam bidang produksi dan penjualan berbagai macam kue berkualitas tinggi. Berawal dari kecintaan kami terhadap seni pembuatan kue, kami selalu berkomitmen menghadirkan cita rasa yang autentik dan lezat di setiap sajian.
            </p>
            <p>
                Kami menyediakan beraneka ragam produk kue untuk memeriahkan berbagai momen berharga Anda, mulai dari hantaran keluarga, perayaan ulang tahun, pesta pernikahan, hingga acara spesial lainnya.
            </p>
        </section>

        <section class="features-grid">
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fa-solid fa-wheat-awn"></i>
                </div>
                <h3>Bahan Segar & Premium</h3>
                <p>Menggunakan bahan-bahan pilihan berkualitas terbaik tanpa pengawet buatan.</p>
            </div>

            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <h3>Dibuat Penuh Cinta</h3>
                <p>Setiap kue diproduksi secara higienis oleh staf berpengalaman dengan resep autentik.</p>
            </div>

            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fa-solid fa-truck-fast"></i>
                </div>
                <h3>Pesanan Selalu Fresh</h3>
                <p>Kue siap dikirim dalam kondisi paling segar langsung dari dapur kami ke tempat Anda.</p>
            </div>
        </section>

        <section class="contact-section">
            <div class="contact-header">
                <h2>Hubungi Kami</h2>
                <p>Punya pertanyaan atau ingin memesan kue kustom? Silakan hubungi kami melalui media di bawah ini</p>
            </div>

            <div class="contact-grid">
                <a href="https://wa.me/6281234567890" target="_blank" class="contact-item">
                    <div class="contact-icon" style="color: #25D366;">
                        <i class="fa-brands fa-whatsapp"></i>
                    </div>
                    <div class="contact-info">
                        <h4>WhatsApp</h4>
                        <p>+62 812-3456-7890</p>
                    </div>
                </a>

                <a href="https://instagram.com/sweetcake" target="_blank" class="contact-item">
                    <div class="contact-icon" style="color: #E4405F;">
                        <i class="fa-brands fa-instagram"></i>
                    </div>
                    <div class="contact-info">
                        <h4>Instagram</h4>
                        <p>@sweetcake</p>
                    </div>
                </a>

                <div class="contact-item">
                    <div class="contact-icon">
                        <i class="fa-solid fa-location-dot"></i>
                    </div>
                    <div class="contact-info">
                        <h4>Lokasi Toko</h4>
                        <p>Jl. Mawar No. 12, Indonesia</p>
                    </div>
                </div>
            </div>
        </section>

    </main>

</body>

</html>