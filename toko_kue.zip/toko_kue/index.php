<?php

require_once __DIR__ . "/config/database.php";

$query = mysqli_query(
    $conn,
    "SELECT * FROM produk
     ORDER BY id DESC
     LIMIT 6"
);

?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sweet Cake - Toko Kue Lezat & Premium</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Playfair+Display:ital,wght@0,600;1,400&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        :root {
            --primary: #e63946;
            --primary-hover: #c1121f;
            --secondary: #ffb703;
            --accent: #fdf0ed;
            --text-dark: #1d3557;
            --text-muted: #6c757d;
            --bg-light: #fafafa;
            --white: #ffffff;
            --shadow-sm: 0 4px 6px -1px rgba(0, 0, 0, 0.05);
            --shadow-lg: 0 20px 25px -5px rgba(0, 0, 0, 0.08), 0 8px 10px -6px rgba(0, 0, 0, 0.01);
            --radius-md: 16px;
            --radius-lg: 24px;
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: var(--bg-light);
            color: var(--text-dark);
            line-height: 1.6;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 24px;
        }

        .navbar {
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(12px);
            position: sticky;
            top: 0;
            z-index: 1000;
            border-bottom: 1px solid rgba(0, 0, 0, 0.05);
            padding: 16px 0;
        }

        .navbar .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .brand {
            font-family: 'Playfair Display', serif;
            font-size: 1.75rem;
            font-weight: 700;
            color: var(--primary);
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .nav-links {
            display: flex;
            gap: 32px;
            list-style: none;
        }

        .nav-links a {
            text-decoration: none;
            color: var(--text-dark);
            font-weight: 600;
            font-size: 0.95rem;
            transition: var(--transition);
            position: relative;
        }

        .nav-links a:hover,
        .nav-links a.active {
            color: var(--primary);
        }

        .nav-links a::after {
            content: '';
            position: absolute;
            bottom: -6px;
            left: 0;
            width: 0%;
            height: 2px;
            background: var(--primary);
            transition: var(--transition);
            border-radius: 2px;
        }

        .nav-links a:hover::after,
        .nav-links a.active::after {
            width: 100%;
        }

        .hero {
            background: linear-gradient(135deg, #fff5f5 0%, #fff0f3 100%);
            padding: 96px 0;
            border-radius: 0 0 40px 40px;
            position: relative;
            overflow: hidden;
        }

        .hero::before {
            content: '';
            position: absolute;
            top: -100px;
            right: -100px;
            width: 400px;
            height: 400px;
            background: rgba(230, 57, 70, 0.08);
            border-radius: 50%;
            filter: blur(60px);
        }

        .hero-content {
            max-width: 650px;
            position: relative;
            z-index: 1;
        }

        .hero-badge {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: #ffe3e5;
            color: var(--primary);
            padding: 8px 16px;
            border-radius: 30px;
            font-size: 0.85rem;
            font-weight: 700;
            margin-bottom: 20px;
            letter-spacing: 0.5px;
            text-transform: uppercase;
        }

        .hero h1 {
            font-family: 'Playfair Display', serif;
            font-size: 3.5rem;
            line-height: 1.15;
            color: var(--text-dark);
            margin-bottom: 20px;
        }

        .hero p {
            font-size: 1.15rem;
            color: var(--text-muted);
            margin-bottom: 32px;
        }

        .btn-group {
            display: flex;
            gap: 16px;
            align-items: center;
        }

        .btn {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            padding: 14px 28px;
            border-radius: 30px;
            font-weight: 700;
            text-decoration: none;
            transition: var(--transition);
            cursor: pointer;
            border: none;
            font-size: 0.95rem;
        }

        .btn-primary {
            background: var(--primary);
            color: var(--white);
            box-shadow: 0 10px 20px rgba(230, 57, 70, 0.25);
        }

        .btn-primary:hover {
            background: var(--primary-hover);
            transform: translateY(-2px);
            box-shadow: 0 14px 24px rgba(230, 57, 70, 0.35);
        }

        .btn-outline {
            background: transparent;
            color: var(--text-dark);
            border: 2px solid #e2e8f0;
        }

        .btn-outline:hover {
            border-color: var(--primary);
            color: var(--primary);
            background: var(--white);
        }

        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-end;
            margin: 64px 0 36px 0;
        }

        .section-title h2 {
            font-family: 'Playfair Display', serif;
            font-size: 2.25rem;
            color: var(--text-dark);
        }

        .section-title p {
            color: var(--text-muted);
            font-size: 0.95rem;
            margin-top: 4px;
        }

        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
            gap: 32px;
            margin-bottom: 80px;
        }

        .card {
            background: var(--white);
            border-radius: var(--radius-md);
            overflow: hidden;
            box-shadow: var(--shadow-sm);
            border: 1px solid rgba(0, 0, 0, 0.04);
            transition: var(--transition);
            display: flex;
            flex-direction: column;
            position: relative;
        }

        .card:hover {
            transform: translateY(-8px);
            box-shadow: var(--shadow-lg);
        }

        .card-image-wrapper {
            position: relative;
            width: 100%;
            padding-top: 75%; /* Ratio 4:3 */
            overflow: hidden;
            background: #f8fafc;
        }

        .product-image {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.5s ease;
        }

        .card:hover .product-image {
            transform: scale(1.08);
        }

        .badge-kategori {
            position: absolute;
            top: 16px;
            left: 16px;
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(8px);
            color: var(--text-dark);
            padding: 6px 14px;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 700;
            letter-spacing: 0.5px;
            text-transform: uppercase;
            box-shadow: 0 4px 10px rgba(0,0,0,0.05);
        }

        .card-body {
            padding: 24px;
            display: flex;
            flex-direction: column;
            flex-grow: 1;
        }

        .card-body h3 {
            font-size: 1.25rem;
            font-weight: 700;
            margin-bottom: 8px;
            color: var(--text-dark);
            line-height: 1.3;
        }

        .card-price-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: auto;
            padding-top: 16px;
            border-top: 1px dashed #f1f5f9;
        }

        .price-tag {
            font-size: 1.35rem;
            font-weight: 800;
            color: var(--primary);
        }

        .btn-detail {
            padding: 10px 18px;
            border-radius: 12px;
            background: var(--accent);
            color: var(--primary);
            text-decoration: none;
            font-weight: 700;
            font-size: 0.85rem;
            transition: var(--transition);
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .btn-detail:hover {
            background: var(--primary);
            color: var(--white);
        }

        .empty-state {
            grid-column: 1 / -1;
            text-align: center;
            padding: 64px 20px;
            background: var(--white);
            border-radius: var(--radius-md);
            color: var(--text-muted);
        }

        @media (max-width: 768px) {
            .hero h1 { font-size: 2.5rem; }
            .section-header { flex-direction: column; align-items: flex-start; gap: 12px; }
            .grid { grid-template-columns: 1fr; }
        }
    </style>
</head>

<body>

    <nav class="navbar">
        <div class="container">
            <a href="index.php" class="brand">
                <i class="fa-solid fa-cake-candles"></i> Sweet Cake
            </a>
            <ul class="nav-links">
                <li><a href="index.php" class="active">Beranda</a></li>
                <li><a href="produk.php">Produk</a></li>
                <li><a href="tentang.php">Tentang Kami</a></li>
            </ul>
        </div>
    </nav>

    <section class="hero">
        <div class="container">
            <div class="hero-content">
                <span class="hero-badge">
                    <i class="fa-solid fa-star"></i> Toko Kue Terfavorit
                </span>
                <h1>Rasakan Kelezatan Kue Premium Setiap Hari</h1>
                <p>Dibuat dari bahan-bahan organik pilihan dengan resep autentik. Sempurna untuk merayakan ulang tahun, pernikahan, atau momen manis Anda.</p>
                <div class="btn-group">
                    <a href="produk.php" class="btn btn-primary">
                        <i class="fa-solid fa-store"></i> Lihat Semua Produk
                    </a>
                    <a href="tentang.php" class="btn btn-outline">
                        Tentang Kami
                    </a>
                </div>
            </div>
        </div>
    </section>

    <main class="container">
        <div class="section-header">
            <div class="section-title">
                <h2>Produk Terbaru</h2>
                <p>Koleksi kue paling favorit yang baru saja dibuat hari ini</p>
            </div>
            <a href="produk.php" class="btn-detail" style="background: transparent; color: var(--primary);">
                Lihat Selengkapnya <i class="fa-solid fa-arrow-right"></i>
            </a>
        </div>

        <div class="grid">
            <?php if (mysqli_num_rows($query) > 0): ?>
                <?php while ($row = mysqli_fetch_assoc($query)): ?>
                    <div class="card">
                        <div class="card-image-wrapper">
                            <?php if (!empty($row['kategori'])): ?>
                                <span class="badge-kategori">
                                    <?= htmlspecialchars($row['kategori']); ?>
                                </span>
                            <?php endif; ?>

                            <?php if (!empty($row['gambar'])): ?>
                                <img src="uploads/produk/<?= htmlspecialchars($row['gambar']); ?>" alt="<?= htmlspecialchars($row['nama']); ?>" class="product-image">
                            <?php else: ?>
                                <img src="https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=600&q=80" alt="Default Product" class="product-image">
                            <?php endif; ?>
                        </div>

                        <div class="card-body">
                            <h3><?= htmlspecialchars($row['nama']); ?></h3>

                            <div class="card-price-row">
                                <div class="price-tag">
                                    Rp <?= number_format($row['harga'], 0, ',', '.'); ?>
                                </div>
                                <a href="detail.php?id=<?= $row['id']; ?>" class="btn-detail">
                                    Detail <i class="fa-solid fa-chevron-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="empty-state">
                    <i class="fa-solid fa-box-open" style="font-size: 3rem; margin-bottom: 16px; color: var(--text-muted);"></i>
                    <p>Belum ada produk yang tersedia saat ini.</p>
                </div>
            <?php endif; ?>
        </div>
    </main>

</body>

</html>