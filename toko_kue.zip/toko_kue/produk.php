<?php

// Menggunakan __DIR__ agar path absolut dan konsisten
require_once __DIR__ . '/config/database.php';

// Verifikasi koneksi database
if (!isset($conn) || !$conn) {
    die("Koneksi database gagal. Periksa konfigurasi Anda.");
}

$keyword = $_GET['keyword'] ?? '';

if ($keyword != '') {
    $keyword_safe = mysqli_real_escape_string($conn, $keyword);
    $query = mysqli_query(
        $conn,
        "SELECT * FROM produk
         WHERE nama LIKE '%$keyword_safe%' OR deskripsi LIKE '%$keyword_safe%'
         ORDER BY id DESC"
    );
} else {
    $query = mysqli_query(
        $conn,
        "SELECT * FROM produk
         ORDER BY id DESC"
    );
}

?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Katalog Produk - Sweet Cake</title>

    <!-- Google Fonts & Font Awesome Icons -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Playfair+Display:ital,wght@0,600;1,400&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        :root {
            --primary: #e63946;
            --primary-hover: #c1121f;
            --secondary: #ffb703;
            --accent: #fdf0ed;
            --text-dark: #1d3557;
            --text-muted: #6c757d;
            --bg-light: #fafafa;
            --white: #ffffff;
            --shadow-sm: 0 4px 6px -1px rgba(0, 0, 0, 0.05);
            --shadow-lg: 0 20px 25px -5px rgba(0, 0, 0, 0.08), 0 8px 10px -6px rgba(0, 0, 0, 0.01);
            --radius-md: 16px;
            --radius-lg: 24px;
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: var(--bg-light);
            color: var(--text-dark);
            line-height: 1.6;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 24px;
        }

        /* Navbar Modern */
        .navbar {
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(12px);
            position: sticky;
            top: 0;
            z-index: 1000;
            border-bottom: 1px solid rgba(0, 0, 0, 0.05);
            padding: 16px 0;
        }

        .navbar .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .brand {
            font-family: 'Playfair Display', serif;
            font-size: 1.75rem;
            font-weight: 700;
            color: var(--primary);
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .nav-links {
            display: flex;
            gap: 32px;
            list-style: none;
        }

        .nav-links a {
            text-decoration: none;
            color: var(--text-dark);
            font-weight: 600;
            font-size: 0.95rem;
            transition: var(--transition);
            position: relative;
        }

        .nav-links a:hover,
        .nav-links a.active {
            color: var(--primary);
        }

        .nav-links a::after {
            content: '';
            position: absolute;
            bottom: -6px;
            left: 0;
            width: 0%;
            height: 2px;
            background: var(--primary);
            transition: var(--transition);
            border-radius: 2px;
        }

        .nav-links a:hover::after,
        .nav-links a.active::after {
            width: 100%;
        }

        /* Header Banner Halaman Produk */
        .page-header {
            background: linear-gradient(135deg, #fff5f5 0%, #fff0f3 100%);
            padding: 60px 0 40px 0;
            border-radius: 0 0 30px 30px;
            margin-bottom: 40px;
            text-align: center;
        }

        .page-header h1 {
            font-family: 'Playfair Display', serif;
            font-size: 2.75rem;
            color: var(--text-dark);
            margin-bottom: 8px;
        }

        .page-header p {
            color: var(--text-muted);
            font-size: 1.05rem;
        }

        /* Form Pencarian Modern */
        .search-box {
            background: var(--white);
            padding: 12px;
            border-radius: 50px;
            box-shadow: var(--shadow-sm);
            border: 1px solid rgba(0, 0, 0, 0.06);
            max-width: 600px;
            margin: -30px auto 48px auto;
            position: relative;
            z-index: 10;
        }

        .search-form {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .search-input-wrapper {
            display: flex;
            align-items: center;
            flex-grow: 1;
            padding-left: 18px;
            gap: 12px;
            color: var(--text-muted);
        }

        .search-input-wrapper input {
            width: 100%;
            border: none;
            outline: none;
            font-family: inherit;
            font-size: 0.95rem;
            color: var(--text-dark);
            background: transparent;
        }

        .btn-search {
            background: var(--primary);
            color: var(--white);
            border: none;
            padding: 12px 28px;
            border-radius: 30px;
            font-weight: 700;
            font-size: 0.9rem;
            cursor: pointer;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .btn-search:hover {
            background: var(--primary-hover);
            transform: translateY(-1px);
        }

        /* Status Hasil Pencarian */
        .search-status {
            margin-bottom: 24px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .search-status p {
            font-size: 0.95rem;
            color: var(--text-muted);
        }

        .btn-reset {
            color: var(--primary);
            text-decoration: none;
            font-weight: 600;
            font-size: 0.85rem;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .btn-reset:hover {
            text-decoration: underline;
        }

        /* Grid & Card Produk */
        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
            gap: 32px;
            margin-bottom: 80px;
        }

        .card {
            background: var(--white);
            border-radius: var(--radius-md);
            overflow: hidden;
            box-shadow: var(--shadow-sm);
            border: 1px solid rgba(0, 0, 0, 0.04);
            transition: var(--transition);
            display: flex;
            flex-direction: column;
        }

        .card:hover {
            transform: translateY(-8px);
            box-shadow: var(--shadow-lg);
        }

        .card-image-wrapper {
            position: relative;
            width: 100%;
            padding-top: 75%; /* Ratio 4:3 */
            overflow: hidden;
            background: #f8fafc;
        }

        .product-image {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.5s ease;
        }

        .card:hover .product-image {
            transform: scale(1.08);
        }

        .badge-kategori {
            position: absolute;
            top: 16px;
            left: 16px;
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(8px);
            color: var(--text-dark);
            padding: 6px 14px;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 700;
            letter-spacing: 0.5px;
            text-transform: uppercase;
            box-shadow: 0 4px 10px rgba(0,0,0,0.05);
        }

        .card-body {
            padding: 24px;
            display: flex;
            flex-direction: column;
            flex-grow: 1;
        }

        .card-body h3 {
            font-size: 1.25rem;
            font-weight: 700;
            margin-bottom: 8px;
            color: var(--text-dark);
            line-height: 1.3;
        }

        .card-body .deskripsi {
            color: var(--text-muted);
            font-size: 0.875rem;
            margin-bottom: 16px;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
            line-height: 1.5;
        }

        .card-price-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: auto;
            padding-top: 16px;
            border-top: 1px dashed #f1f5f9;
        }

        .price-tag {
            font-size: 1.35rem;
            font-weight: 800;
            color: var(--primary);
        }

        .btn-detail {
            padding: 10px 18px;
            border-radius: 12px;
            background: var(--accent);
            color: var(--primary);
            text-decoration: none;
            font-weight: 700;
            font-size: 0.85rem;
            transition: var(--transition);
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .btn-detail:hover {
            background: var(--primary);
            color: var(--white);
        }

        /* Empty State */
        .empty-state {
            grid-column: 1 / -1;
            text-align: center;
            padding: 64px 20px;
            background: var(--white);
            border-radius: var(--radius-md);
            color: var(--text-muted);
            box-shadow: var(--shadow-sm);
        }

        /* Responsive */
        @media (max-width: 768px) {
            .page-header h1 { font-size: 2rem; }
            .grid { grid-template-columns: 1fr; }
            .search-box { margin-left: 16px; margin-right: 16px; }
        }
    </style>
</head>

<body>

    <!-- Navbar -->
    <nav class="navbar">
        <div class="container">
            <a href="index.php" class="brand">
                <i class="fa-solid fa-cake-candles"></i> Sweet Cake
            </a>
            <ul class="nav-links">
                <li><a href="index.php">Beranda</a></li>
                <li><a href="produk.php" class="active">Produk</a></li>
                <li><a href="tentang.php">Tentang Kami</a></li>
            </ul>
        </div>
    </nav>

    <!-- Header Halaman -->
    <section class="page-header">
        <div class="container">
            <h1>Katalog Produk</h1>
            <p>Temukan aneka pilihan kue lezat buatan kami yang siap menemani momen spesial Anda</p>
        </div>
    </section>

    <main class="container">
        <!-- Form Pencarian Interaktif -->
        <div class="search-box">
            <form method="GET" class="search-form">
                <div class="search-input-wrapper">
                    <i class="fa-solid fa-magnifying-glass"></i>
                    <input type="text" name="keyword" placeholder="Cari berdasarkan nama atau deskripsi kue..." value="<?= htmlspecialchars($keyword); ?>">
                </div>
                <button type="submit" class="btn-search">
                    Cari
                </button>
            </form>
        </div>

        <!-- Notifikasi Keterangan Pencarian -->
        <?php if (!empty($keyword)): ?>
            <div class="search-status">
                <p>Menampilkan hasil pencarian untuk: <strong>"<?= htmlspecialchars($keyword); ?>"</strong></p>
                <a href="produk.php" class="btn-reset">
                    <i class="fa-solid fa-rotate-left"></i> Reset Pencarian
                </a>
            </div>
        <?php endif; ?>

        <!-- Grid Produk -->
        <div class="grid">
            <?php if ($query && mysqli_num_rows($query) > 0): ?>
                <?php while ($row = mysqli_fetch_assoc($query)): ?>
                    <div class="card">
                        <div class="card-image-wrapper">
                            <?php if (!empty($row['kategori'])): ?>
                                <span class="badge-kategori">
                                    <?= htmlspecialchars($row['kategori']); ?>
                                </span>
                            <?php endif; ?>

                            <?php if (!empty($row['gambar'])): ?>
                                <img src="uploads/produk/<?= htmlspecialchars($row['gambar']); ?>" alt="<?= htmlspecialchars($row['nama']); ?>" class="product-image">
                            <?php else: ?>
                                <img src="https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=600&q=80" alt="Default Product" class="product-image">
                            <?php endif; ?>
                        </div>

                        <div class="card-body">
                            <h3><?= htmlspecialchars($row['nama']); ?></h3>

                            <?php if (!empty($row['deskripsi'])): ?>
                                <p class="deskripsi"><?= htmlspecialchars($row['deskripsi']); ?></p>
                            <?php endif; ?>

                            <div class="card-price-row">
                                <div class="price-tag">
                                    Rp <?= number_format($row['harga'], 0, ',', '.'); ?>
                                </div>
                                <a href="detail.php?id=<?= $row['id']; ?>" class="btn-detail">
                                    Detail <i class="fa-solid fa-chevron-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="empty-state">
                    <i class="fa-solid fa-magnifying-glass" style="font-size: 3rem; margin-bottom: 16px; color: var(--text-muted);"></i>
                    <h3>Produk tidak ditemukan</h3>
                    <p style="margin-top: 8px;">Coba gunakan kata kunci lain atau lihat daftar seluruh produk kami.</p>
                    <?php if (!empty($keyword)): ?>
                        <a href="produk.php" class="btn-search" style="display: inline-flex; margin-top: 20px; text-decoration: none;">
                            Tampilkan Semua Produk
                        </a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </main>

</body>

</html>